"""Web server for the reminder management system.

Run:  python app.py   then open  http://127.0.0.1:5000
"""
from flask import Flask, abort, jsonify, request, send_from_directory

from reminders_core import (
    BASE_DIR,
    due_reminders,
    load_store,
    save_customers,
    save_settings,
)

app = Flask(__name__, static_folder=str(BASE_DIR / "static"), static_url_path="")


@app.get("/")
def index():
    return send_from_directory(BASE_DIR / "static", "index.html")


@app.get("/api/customers")
def get_customers():
    return jsonify(load_store()["customers"])


@app.put("/api/customers")
def put_customers():
    customers = request.get_json(silent=True)
    if not isinstance(customers, list):
        abort(400, description="Expected a list of customers")
    save_customers(customers)
    return jsonify({"ok": True, "count": len(customers)})


@app.get("/api/settings")
def get_settings():
    return jsonify(load_store()["settings"])


@app.put("/api/settings")
def put_settings():
    settings = request.get_json(silent=True)
    if not isinstance(settings, dict):
        abort(400, description="Expected a settings object")
    save_settings(settings)
    return jsonify({"ok": True})


@app.get("/api/due")
def get_due():
    days = request.args.get("days", default=0, type=int)
    items = due_reminders(load_store()["customers"], days_ahead=days)
    return jsonify(items)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
