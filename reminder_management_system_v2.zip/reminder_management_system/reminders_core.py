"""Shared logic for the reminder management system.

Stores all data in data/store.json and finds reminders that are due.
"""
import json
import os
import tempfile
import threading
from datetime import date, timedelta
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "data" / "store.json"
OUTBOX_DIR = BASE_DIR / "outbox"

DEFAULT_SETTINGS = {"shopName": "RO Shop"}
_lock = threading.Lock()


def _default_store():
    return {"customers": [], "settings": dict(DEFAULT_SETTINGS)}


def load_store():
    """Return the whole data store (customers + settings)."""
    with _lock:
        if not DATA_FILE.exists():
            return _default_store()
        with DATA_FILE.open(encoding="utf-8") as f:
            data = json.load(f)
    data.setdefault("customers", [])
    data.setdefault("settings", dict(DEFAULT_SETTINGS))
    return data


def save_store(data):
    """Write the store atomically so a crash never leaves a half-written file."""
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    with _lock:
        fd, tmp_path = tempfile.mkstemp(dir=DATA_FILE.parent, suffix=".tmp")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp_path, DATA_FILE)


def save_customers(customers):
    store = load_store()
    store["customers"] = customers
    save_store(store)


def save_settings(settings):
    store = load_store()
    store["settings"] = settings
    save_store(store)


def service_name(customer):
    return customer.get("planType") or customer.get("roModel") or "service"


def due_reminders(customers, days_ahead=0, today=None):
    """List unfinished reminders that are overdue, due today, or due within days_ahead days."""
    today = today or date.today()
    horizon = today + timedelta(days=days_ahead)
    results = []
    for customer in customers:
        for reminder in customer.get("reminders", []):
            if reminder.get("done"):
                continue
            try:
                due = date.fromisoformat(reminder["date"])
            except (KeyError, TypeError, ValueError):
                continue
            if due > horizon:
                continue
            if due < today:
                status = "overdue"
            elif due == today:
                status = "today"
            else:
                status = "upcoming"
            results.append({
                "customer_id": customer.get("id"),
                "reminder_id": reminder.get("id"),
                "customer": customer.get("name", ""),
                "phone": customer.get("phone", ""),
                "service": service_name(customer),
                "description": reminder.get("description", ""),
                "date": reminder["date"],
                "status": status,
            })
    results.sort(key=lambda r: r["date"])
    return results
