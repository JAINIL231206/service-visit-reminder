#!/usr/bin/env bash
# Start the reminder management system (creates a virtual environment on first run).
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
  python3 -m venv .venv
  .venv/bin/pip install -r requirements.txt
fi
.venv/bin/python app.py
