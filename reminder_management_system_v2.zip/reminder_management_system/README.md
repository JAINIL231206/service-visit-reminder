# Reminder Management System

Service reminders for RO, AC, car and other services. Built with a Python (Flask) server and a single-page web app.

## Project structure

```
reminder_management_system/
├── app.py              Flask web server and JSON API
├── reminders_core.py   Data storage and due-reminder logic
├── check_reminders.py  Command-line checker that writes messages to outbox/
├── static/
│   └── index.html      The web app (customers + reminders)
├── data/
│   └── store.json      All customers and settings (created automatically)
├── outbox/             Generated reminder message files
├── requirements.txt    Python dependencies
├── run.sh              Start script (Mac/Linux)
└── run.bat             Start script (Windows)
```

## Setup

You need Python 3.9 or newer.

**Windows:** double-click `run.bat`
**Mac/Linux:** `./run.sh`

Or manually:

```bash
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Then open **http://127.0.0.1:5000** in your browser.

## Using the app

- **Customers tab:** add customers, record payments, and set up service reminders.
- **Reminders tab:** see overdue, due-today, and upcoming visits. Filter by RO, AC, car, or other. Mark visits done and send reminder messages.
- All data is saved to `data/store.json` on this computer.

## Messaging and reminders

- **Channels:** each reminder, receipt, or schedule message opens in a send window with WhatsApp (default), SMS, or email. You can edit the message before sending. Nothing is sent automatically; your app opens with the message ready and you tap send.
- **Three parties:** send a visit reminder to the customer, the technician (the customer's address is included), or the shop owner. Set the technician and owner numbers under **Settings**.
- **Advance reminders:** visits due within N days (default 3, set under Settings) are shown as "Due in Xd".
- **Reschedule:** use +1 week, +2 weeks, +1 month, or a chosen date. The original date is kept, and a reschedule message is offered straight away.
- **Contract progress:** the customer view shows "x of 4 visits completed". When visit four is done, the contract is flagged complete and a renewal offer is opened.
- **Message history:** each customer's record lists the messages sent, to whom, and by which channel. Sending is recorded when the message is opened, not when it is delivered.

## Daily reminder check

Run this to see what is due and create message files in `outbox/`:

```bash
python check_reminders.py            # overdue and due today
python check_reminders.py --days 7   # also the next 7 days
```

To run it automatically each morning:
- **Windows:** Task Scheduler, action "Start a program": `C:\path\to\.venv\Scripts\python.exe` with argument `check_reminders.py` and start in folder `C:\path\to\reminder_management_system`.
- **Mac/Linux:** add to crontab (`crontab -e`): `0 9 * * * cd /path/to/reminder_management_system && .venv/bin/python check_reminders.py`

## Backup and moving data

- Use **Backup** in the app to download a JSON file, and **Restore** to load it.
- You can also copy `data/store.json` directly.
- Data saved in the older single-file version (browser storage) is not moved automatically. Open that version, use its Backup button, then use Restore in this app.

## JSON API

| Method | Path | Purpose |
|---|---|---|
| GET / PUT | `/api/customers` | Read or replace all customers |
| GET / PUT | `/api/settings` | Read or replace settings (shop name) |
| GET | `/api/due?days=N` | Overdue, due-today, and reminders due within N days |
