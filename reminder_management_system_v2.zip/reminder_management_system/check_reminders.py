"""Print due reminders and write ready-to-send messages to the outbox folder.

Examples:
  python check_reminders.py              # overdue + due today
  python check_reminders.py --days 7     # also show the next 7 days
"""
import argparse
from datetime import datetime

from reminders_core import OUTBOX_DIR, due_reminders, load_store


def build_message(item, shop_name):
    if item["status"] == "overdue":
        when = f"was due on {item['date']}"
    elif item["status"] == "today":
        when = "is due today"
    else:
        when = f"is due on {item['date']}"
    return (
        f"{shop_name}: Dear {item['customer']}, your {item['service']} "
        f"{when}. Please contact us to book the visit. Thank you."
    )


def main():
    parser = argparse.ArgumentParser(description="Check service reminders")
    parser.add_argument("--days", type=int, default=0,
                        help="also include reminders due within this many days")
    args = parser.parse_args()

    store = load_store()
    shop = store["settings"].get("shopName", "Service")
    items = due_reminders(store["customers"], days_ahead=args.days)

    if not items:
        print("No reminders due.")
        return

    print(f"{len(items)} reminder(s):\n")
    lines = []
    for item in items:
        line = (f"[{item['status'].upper():8}] {item['date']}  {item['customer']:<20} "
                f"{item['phone']:<14} {item['service']}")
        if item["description"]:
            line += f"  ({item['description']})"
        print(line)
        lines.append(f"{item['phone']}\t{build_message(item, shop)}")

    OUTBOX_DIR.mkdir(parents=True, exist_ok=True)
    out_file = OUTBOX_DIR / f"messages_{datetime.now():%Y%m%d_%H%M}.txt"
    out_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"\nMessages saved to {out_file}")


if __name__ == "__main__":
    main()
